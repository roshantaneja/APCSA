import java.awt.Color;

public class Metal extends Particle
{
    
    public Metal()
    {
        super(ParticlesProgram.METAL, Color.gray);
    }

}
