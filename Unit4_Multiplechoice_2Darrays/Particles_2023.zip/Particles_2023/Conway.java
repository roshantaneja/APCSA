import java.awt.Color;

public class Conway extends Particle
{
    
    public Conway()
    {
        super(ParticlesProgram.CONWAY, Color.white);
    }

}
