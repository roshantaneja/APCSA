import java.awt.Color;

public class Empty extends Particle
{

    public Empty()
    {
        super(ParticlesProgram.EMPTY, Color.black);
    }


}
